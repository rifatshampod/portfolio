<!-- Start Footer Area -->
    <div class="rn-footer-area rn-section-gap section-separator">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-area text-center">

                        <div class="logo">
                            <a href="/">
                                <img src="assets/images/logo/logo.png" alt="logo">
                            </a>
                        </div>

                        <p class="description mt--30">© 2021. All rights reserved by <a target="_blank" href="https://rifatshampod.com/">rifatshampod.com</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Area -->