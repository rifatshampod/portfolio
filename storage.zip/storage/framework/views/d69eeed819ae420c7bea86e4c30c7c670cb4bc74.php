
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class="la la-home nav-icon"></i> <?php echo e(trans('backpack::base.dashboard')); ?></a></li>

<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('article')); ?>"><i class="nav-icon la la-question"></i> Articles</a></li>
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('category')); ?>"><i class="nav-icon la la-question"></i> Categories</a></li>
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('tag')); ?>"><i class="nav-icon la la-question"></i> Tags</a></li><?php /**PATH C:\xampp\htdocs\rifatshampod\resources\views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>